export interface Nav{
    url : string;
    label : string;
}