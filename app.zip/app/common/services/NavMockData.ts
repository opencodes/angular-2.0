import {Nav} from './Nav';
export const NAVS:Nav[] = [{
    url : "/",
    label : "Home"
    },{
    url : "/blog",
    label : "Blog"
    },{
    url : "/login",
    label : "Login"
}]