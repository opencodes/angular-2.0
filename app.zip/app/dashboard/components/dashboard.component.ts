import {Component} from '@angular/core';


@Component({
    templateUrl: "./app/dashboard/html/dashboard.html",
    styleUrls: ["./app/dashboard/css/dashboard.css"],
})

export class DashboardComponent{
    title = "Dashboard";
}