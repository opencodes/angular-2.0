import {Component} from '@angular/core';


@Component({
    templateUrl: "./app/blog/html/blog.html",
    styleUrls: ["./app/blog/css/blog.css"],
})

export class BlogComponent{
    title = "BlogComponent";
}