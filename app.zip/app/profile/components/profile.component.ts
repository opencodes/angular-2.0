import {Component} from '@angular/core';


@Component({
    templateUrl: "./app/profile/html/profile.html",
    styleUrls: ["./app/profile/css/profile.css"],
})

export class ProfileComponent{
    title = "Profile"
}