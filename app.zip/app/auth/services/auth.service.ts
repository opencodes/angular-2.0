import {Injectable} from '@angular/core';
import { Http, Response }          from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

import {AUTH_EVENTS, USER_ROLES} from './auth.constant';
import {Auth} from './Auth';
import {Session} from './session.service';


@Injectable()
export class AuthService {
    private postUrl = "https://jsonplaceholder.typicode.com/posts";
    constructor(private http: Http) {};

    public login(): Observable < Auth[] > {
        let headers = new Headers({
            'Content-Type': 'application/json'
        });
        let options = new RequestOptions({
            headers: headers
        });

        return this.http.get(this.postUrl)
            .map(this.extractData)
            .catch(this.handleError);
    }
    
    isAuthenticated():boolean{
        return !!Session.userId;
    }
    isAuthorized ():boolean{
        let authorizedRoles;
        if (!Array.isArray(USER_ROLES)) {
          authorizedRoles = [USER_ROLES];
        }
        return (authService.isAuthenticated() && USER_ROLES.indexOf(Session.userRole) !== -1);
    }
    

    private extractData(res: Response) {
        let body = res.json();
        return body || {};
    }

    private handleError(error: Response | any) {
        // In a real world app, you might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }
}