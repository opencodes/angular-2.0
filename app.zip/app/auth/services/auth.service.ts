import {Injectable} from '@angular/core';
import { Http, Response }          from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

import {AUTH_EVENTS, USER_ROLES} from './auth.constant';
import {Auth} from './Auth';
import {Session} from './session.service';


@Injectable()
export class AuthService {
    private postUrl = "https://jsonplaceholder.typicode.com/posts/1";
    session : any;
    constructor(private http: Http, private _sessionService:Session) {
       this.session = _sessionService; 
    };
    
    public login(): Observable < Auth[] > {
        let self = this;
        let headers = new Headers({
            'Content-Type': 'application/json'
        });
        let options = new RequestOptions({
            headers: headers
        });

        return this.http.get(this.postUrl)
            .map(function(res) {
                let body = res.json();
                self._sessionService.create(body.id, body.userId, 'admin');
                return self.extractData(res);                
            })
            .catch(this.handleError);
    }
    
    public isAuthenticated():boolean{
       
        return !!this._sessionService.userId;
    }
    public isAuthorized ():boolean{
        let authorizedRoles;
        if (!Array.isArray(USER_ROLES)) {
          authorizedRoles = [USER_ROLES];
        }
        return (this.isAuthenticated() && USER_ROLES[this._sessionService.userRole] !== -1);
    }
    

    private extractData(res: Response) {  
        let body = res.json();        
        return body || {};
    }

    private handleError(error: Response | any) {
        // In a real world app, you might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        return Observable.throw(errMsg);
    }
}