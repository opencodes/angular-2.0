import {Injectable} from '@angular/core';

@Injectable()
export class Session {
    id:string;
    userId:number;
    userRole:string;
    
    create(sessionId:string, userId:number, userRole:string): void {
        this.id = sessionId;
        this.userId = userId;
        this.userRole = userRole;
    }
    destroy(): void {
        this.id = null;
        this.userId = null;
        this.userRole = null;
    }
}