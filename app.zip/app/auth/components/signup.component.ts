import {Component} from '@angular/core';

@Component({
  templateUrl: './app/auth/html/signup.html',
  styleUrls: ['./app/auth/css/signup.css']
})

export class SignupComponent  { 
	title = 'Signup Component'; 
}