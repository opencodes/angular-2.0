import {Component, OnInit} from '@angular/core';

import {AuthService} from '../services/auth.service';


@Component({
  templateUrl: './app/auth/html/login.html',
  styleUrls: ['./app/auth/css/login.css']
})

export class LoginComponent  { 
    title = 'Login Component'; 
    user:any;
    errorMessage : string;
    constructor(private _authService: AuthService){
        
    }
    
    login():void{
        this._authService.login().subscribe(
                       user => this.user = user,
                       error =>  this.errorMessage = <any>error);
    }
    
    ngOnInit(){
        this.login();
    }
    
    
}